// Coursework2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Menu.h"

// Driver Program to test above function
int main()
{
	// Calling menu to start the main program
	Menu *newMenu = new Menu();

	return 0;
}
