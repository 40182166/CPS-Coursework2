
Concurrent and Parallel Systems Coursework

Valentina Scarfi - 40182166

***************************************************

This folder contains:

	- AllResults_Table with all timings and graphs
	- A pdf Report
	- Code files, formed by a menu system to navigate through all the options.
	  Serial algorithms are in Serial.cpp
	  OpenMP and Threads algorithms are in two separate classes in Parallel.cpp
	- Performance Profiler reports for both techniques on each algorithm
	- Images folder with all images used in the Report